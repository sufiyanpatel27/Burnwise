export const Header = (props) => {
  return (
    <header id='header'>
      <div className='intro'>
        <div className='overlay'>
          <div className='container'>
            <div className='row'>
              <div className='col-md-8 col-md-offset-2 intro-text'>
                <h1>
                  Motion Fitness
                  <span></span>
                </h1>
                <p>Get your exercise done effectively.</p>
            
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
